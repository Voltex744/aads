// Practical 1: Randomized Quick Sort (counts number of comparisons)
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int comparisons = 0;   // global counter for comparisons

// Partition using the last element as pivot (Lomuto partition)
int partition(int a[], int low, int high) {
    int pivot = a[high];
    int i = low - 1;
    for (int j = low; j < high; j++) {
        comparisons++;              // one comparison: a[j] with pivot
        if (a[j] <= pivot) {
            i++;
            swap(a[i], a[j]);
        }
    }
    swap(a[i + 1], a[high]);
    return i + 1;
}

// Pick a random element, move it to the end, then partition
int randomizedPartition(int a[], int low, int high) {
    int r = low + rand() % (high - low + 1);
    swap(a[r], a[high]);
    return partition(a, low, high);
}

void randomizedQuickSort(int a[], int low, int high) {
    if (low < high) {
        int p = randomizedPartition(a, low, high);
        randomizedQuickSort(a, low, p - 1);
        randomizedQuickSort(a, p + 1, high);
    }
}

int main() {
    srand(time(0));
    int n;
    cout << "Enter number of elements: ";
    cin >> n;
    int a[100];
    cout << "Enter " << n << " elements: ";
    for (int i = 0; i < n; i++)
        cin >> a[i];

    randomizedQuickSort(a, 0, n - 1);

    cout << "Sorted array: ";
    for (int i = 0; i < n; i++)
        cout << a[i] << " ";
    cout << "\nNumber of comparisons: " << comparisons << endl;
    return 0;
}

/*
=====================================================================
                FULL EXPLANATION - RANDOMIZED QUICK SORT
=====================================================================

---------------------------------------------------------------------
PART A : THE TOPIC
---------------------------------------------------------------------
1. What is Quick Sort?
   Quick Sort is a "divide and conquer" sorting algorithm.
   - DIVIDE  : choose one element called the PIVOT. Rearrange the array
               so that all elements <= pivot come to its LEFT and all
               bigger elements come to its RIGHT. Now the pivot is at its
               correct (final) sorted position.
   - CONQUER : sort the left part and the right part recursively.
   - COMBINE : nothing to do; the array is already sorted in place.

2. Problem with normal Quick Sort
   If we always take the last (or first) element as pivot and the input
   is already sorted (or reverse sorted), the pivot is always the
   smallest/largest element. Then one side has n-1 elements and the
   other side has 0. This gives the WORST case O(n^2).

3. What does "Randomized" mean?
   Instead of fixed position, we choose the pivot at RANDOM from the
   current sub-array. Now no particular input can always make it slow.
   The bad case can still happen, but only by very bad luck, so the
   EXPECTED running time becomes O(n log n) for every input.

4. Time and space complexity
   - Best case     : O(n log n)  (pivot splits array into equal halves)
   - Expected case : O(n log n)  (for any input, because pivot is random)
   - Worst case    : O(n^2)      (very unlucky random choices)
   - Extra space   : O(log n) expected, for the recursion stack
   - It is IN-PLACE (no extra array) but NOT STABLE.

5. Number of comparisons
   Expected number of comparisons is about 2 n ln n  (approx 1.39 n log2 n).
   The program counts every comparison "a[j] <= pivot" and prints it.
   Because the pivot is random, the count can change on every run even
   for the same input.

---------------------------------------------------------------------
PART B : EXPLANATION OF EACH PART OF THE CODE
---------------------------------------------------------------------
1. Header files
   #include <iostream> -> for cin and cout.
   #include <cstdlib>  -> for rand() and srand().
   #include <ctime>    -> for time(0), used as seed for srand().

2. int comparisons = 0;
   A GLOBAL counter. Global so that every function (partition) can
   increase it, and main() can print it at the end.

3. partition(a, low, high)   (Lomuto partition scheme)
   - pivot = a[high]  -> the last element is the pivot.
   - i = low - 1      -> i marks the end of the "<= pivot" region.
   - Loop j from low to high-1:
        comparisons++  -> we are comparing a[j] with pivot once.
        if a[j] <= pivot, increase i and swap a[i] and a[j],
        so the small element moves into the left region.
   - After the loop, swap a[i+1] and a[high]: the pivot goes just after
     the small elements, i.e. to its correct position.
   - Return i+1 = final index of pivot.
   One call does (high - low) comparisons.

4. randomizedPartition(a, low, high)
   - r = low + rand() % (high - low + 1)
       rand() % (size) gives a number from 0 to size-1, adding low
       gives a random index between low and high.
   - swap(a[r], a[high]) -> move the random element to the end, so the
     normal partition() can use it as pivot.
   - return partition(a, low, high).

5. randomizedQuickSort(a, low, high)
   - Base case: if low >= high, sub-array has 0 or 1 element -> already
     sorted, do nothing.
   - Otherwise: p = randomizedPartition(...) gives pivot position.
     Recursively sort a[low..p-1] and a[p+1..high].
     The pivot a[p] is not included again since it is already in place.

6. main()
   - srand(time(0)) -> seeds the random generator with current time, so
     we get different random numbers on each run. Without it, rand()
     gives the same sequence every time.
   - Read n and the n elements into array a[100] (max 100 elements).
   - Call randomizedQuickSort(a, 0, n-1).
   - Print the sorted array and the number of comparisons.

---------------------------------------------------------------------
PART C : VIVA QUESTIONS WITH ANSWERS
---------------------------------------------------------------------
Q1. What is the difference between Quick Sort and Randomized Quick Sort?
A.  Only the choice of pivot. Normal quick sort uses a fixed position
    (first/last element); randomized quick sort picks a random element.
    This makes the expected time O(n log n) for every input.

Q2. What is the worst case of Randomized Quick Sort? Can it still happen?
A.  O(n^2). Yes, it can happen if the random pivot is always the
    smallest or largest element, but the probability is extremely small.

Q3. Why is it called a Las Vegas algorithm?
A.  Because it ALWAYS gives the correct (sorted) answer; only the
    running time is random. (A Monte Carlo algorithm has fixed time but
    the answer may be wrong with small probability.)

Q4. What is the expected number of comparisons?
A.  About 2 n ln n, i.e. O(n log n).

Q5. Why do we use srand(time(0))?
A.  To give a different seed each run. Otherwise rand() returns the
    same sequence of numbers every time the program runs.

Q6. Why do we swap the random element with a[high]?
A.  Our partition function always uses a[high] as pivot. Swapping
    places the random pivot there so we can reuse the same partition.

Q7. Which partition scheme is used? Name another.
A.  Lomuto partition (pivot = last element). Another one is Hoare
    partition, which uses two pointers moving from both ends and does
    fewer swaps.

Q8. Is Quick Sort stable? Is it in-place?
A.  Not stable (equal elements can change their relative order).
    It is in-place (only O(log n) stack space on average).

Q9. Why does the number of comparisons change each time we run it?
A.  Because different random pivots give different splits, and the
    number of comparisons depends on how balanced the splits are.

Q10. Why is Quick Sort usually faster than Merge Sort in practice
     even though both are O(n log n)?
A.  Quick sort is in-place (no extra array), has a small constant
    factor and good cache behaviour.

Q11. What is the recurrence for the best and worst case?
A.  Best:  T(n) = 2T(n/2) + O(n)  -> O(n log n)
    Worst: T(n) = T(n-1) + O(n)   -> O(n^2)

Q12. What happens if all elements are equal?
A.  With Lomuto partition, every element is <= pivot, so all go to the
    left side and it becomes O(n^2). A 3-way partition fixes this.
=====================================================================
*/
