// Practical 2: Find the i-th smallest element using Randomized Select
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

// Partition using the last element as pivot
int partition(int a[], int low, int high) {
    int pivot = a[high];
    int i = low - 1;
    for (int j = low; j < high; j++) {
        if (a[j] <= pivot) {
            i++;
            swap(a[i], a[j]);
        }
    }
    swap(a[i + 1], a[high]);
    return i + 1;
}

// Pick a random pivot, then partition
int randomizedPartition(int a[], int low, int high) {
    int r = low + rand() % (high - low + 1);
    swap(a[r], a[high]);
    return partition(a, low, high);
}

// Returns the i-th smallest element in a[low..high]
int randomizedSelect(int a[], int low, int high, int i) {
    if (low == high)
        return a[low];

    int q = randomizedPartition(a, low, high);
    int k = q - low + 1;          // number of elements in the left part (incl. pivot)

    if (i == k)                   // pivot is the answer
        return a[q];
    else if (i < k)               // answer is in the left part
        return randomizedSelect(a, low, q - 1, i);
    else                          // answer is in the right part
        return randomizedSelect(a, q + 1, high, i - k);
}

int main() {
    srand(time(0));
    int n, i;
    cout << "Enter number of elements: ";
    cin >> n;
    int a[100];
    cout << "Enter " << n << " elements: ";
    for (int j = 0; j < n; j++)
        cin >> a[j];

    cout << "Enter i (1 to " << n << "): ";
    cin >> i;

    if (i < 1 || i > n) {
        cout << "Invalid value of i" << endl;
        return 0;
    }

    cout << "The " << i << "-th smallest element is: "
         << randomizedSelect(a, 0, n - 1, i) << endl;
    return 0;
}

/*
=====================================================================
                 FULL EXPLANATION - RANDOMIZED SELECT
=====================================================================

---------------------------------------------------------------------
PART A : THE TOPIC
---------------------------------------------------------------------
1. The Selection Problem
   Given an array of n numbers and a number i (1 <= i <= n), find the
   i-th smallest element (also called the i-th ORDER STATISTIC).
   - i = 1         -> minimum
   - i = n         -> maximum
   - i = (n+1)/2   -> median

2. Simple method
   Sort the array and return a[i-1]. This takes O(n log n).
   But we do not need the whole array sorted, we only need ONE element.
   So we can do better: O(n) expected time.

3. Idea of Randomized Select
   It is like Quick Sort, but after partitioning we go into ONLY ONE
   side (the side that contains the answer).
   - Partition the array around a random pivot. The pivot lands at its
     correct sorted position q.
   - Let k = number of elements from low to q (left part + pivot).
   - If i == k -> pivot is exactly the i-th smallest. Done.
   - If i <  k -> answer is in the left part; find i-th smallest there.
   - If i >  k -> answer is in the right part; but k elements are
                  already smaller, so find the (i-k)-th smallest there.

4. Complexity
   - Expected time : O(n)  (work is n + n/2 + n/4 + ... = about 2n)
   - Worst case    : O(n^2) (very unlucky pivots)
   - There is also a deterministic "Median of Medians" algorithm with
     worst case O(n), but it is more complicated.

---------------------------------------------------------------------
PART B : EXPLANATION OF EACH PART OF THE CODE
---------------------------------------------------------------------
1. Header files: iostream (input/output), cstdlib (rand, srand),
   ctime (time for seeding).

2. partition(a, low, high)
   Same Lomuto partition as Quick Sort. Uses a[high] as pivot, moves
   all smaller-or-equal elements to the left, puts pivot in its final
   place and returns that index.

3. randomizedPartition(a, low, high)
   Chooses a random index r between low and high, swaps a[r] with
   a[high] and calls partition. So the pivot is random.

4. randomizedSelect(a, low, high, i)
   - Base case: if low == high, only one element is left, and it must
     be the answer, so return a[low].
   - q = randomizedPartition(a, low, high)  -> pivot index.
   - k = q - low + 1  -> position (rank) of pivot inside this sub-array.
     NOTE: we use "q - low + 1", not just "q + 1", because the
     sub-array may not start at index 0.
   - if (i == k)  return a[q];
   - else if (i < k) search left part  a[low .. q-1] for i-th smallest.
   - else search right part a[q+1 .. high] for (i-k)-th smallest,
     because k smaller elements are thrown away on the left.

5. main()
   - srand(time(0)) seeds the random generator.
   - Reads n, the array, and i.
   - Checks that 1 <= i <= n, otherwise prints "Invalid value of i".
   - Calls randomizedSelect(a, 0, n-1, i) and prints the result.
   NOTE: the array gets rearranged during the process (partitioning
   is done in place), but the answer is correct.

---------------------------------------------------------------------
PART C : VIVA QUESTIONS WITH ANSWERS
---------------------------------------------------------------------
Q1. What is an order statistic?
A.  The i-th order statistic is the i-th smallest element of a set.
    Minimum is the 1st, maximum is the n-th order statistic.

Q2. What is the expected time of Randomized Select? Why is it less
    than Quick Sort?
A.  O(n). Quick sort recurses on BOTH sides, but select recurses on
    only ONE side, so the work keeps halving: n + n/2 + n/4 ... = O(n).

Q3. What is the worst case time?
A.  O(n^2), when the pivot is always the smallest or largest element.

Q4. Why do we search for (i - k) in the right part?
A.  The left part plus the pivot contain k elements that are all
    smaller than everything in the right part. So the i-th smallest
    overall is the (i-k)-th smallest of the right part.

Q5. Why k = q - low + 1 and not q + 1?
A.  In recursive calls the sub-array starts at "low", not 0. So the
    pivot's rank inside the sub-array is q - low + 1.

Q6. Which algorithm finds the i-th smallest in worst case O(n)?
A.  The "Median of Medians" (SELECT / BFPRT) algorithm. It divides the
    array into groups of 5, finds medians, and uses the median of
    those medians as a good pivot.

Q7. How can you find the median using this program?
A.  Give i = (n+1)/2 (for odd n).

Q8. Is Randomized Select Las Vegas or Monte Carlo?
A.  Las Vegas - the answer is always correct; only the time is random.

Q9. Does this program change the original array?
A.  Yes, partitioning rearranges elements in place. If we need the
    original order, we should work on a copy.

Q10. What is the recurrence for expected time?
A.  Roughly T(n) <= T(3n/4) + O(n) on average, which solves to O(n).

Q11. Can we use a min-heap instead? What is the time?
A.  Yes: build heap O(n) and extract-min i times O(i log n). Total
    O(n + i log n), which is worse than O(n) for large i.
=====================================================================
*/
