// Practical 3: Minimum Spanning Tree using Kruskal's Algorithm
#include <iostream>
#include <algorithm>
using namespace std;

struct Edge {
    int u, v, w;   // edge from u to v with weight w
};

int parent[100];

// Find the representative (root) of the set containing x
int findSet(int x) {
    while (parent[x] != x)
        x = parent[x];
    return x;
}

// Used by sort() to arrange edges by increasing weight
bool compareEdges(Edge a, Edge b) {
    return a.w < b.w;
}

int main() {
    int V, E;
    cout << "Enter number of vertices and edges: ";
    cin >> V >> E;

    Edge edges[100];
    cout << "Enter each edge as: u v weight (vertices numbered 0 to " << V - 1 << ")\n";
    for (int i = 0; i < E; i++)
        cin >> edges[i].u >> edges[i].v >> edges[i].w;

    // Step 1: sort edges by weight
    sort(edges, edges + E, compareEdges);

    // Step 2: every vertex starts in its own set
    for (int i = 0; i < V; i++)
        parent[i] = i;

    // Step 3: pick the smallest edge that does not form a cycle
    int totalCost = 0, count = 0;
    cout << "\nEdges in the Minimum Spanning Tree:\n";
    for (int i = 0; i < E && count < V - 1; i++) {
        int rootU = findSet(edges[i].u);
        int rootV = findSet(edges[i].v);
        if (rootU != rootV) {           // different sets -> no cycle
            cout << edges[i].u << " - " << edges[i].v
                 << "  (weight " << edges[i].w << ")\n";
            totalCost += edges[i].w;
            parent[rootU] = rootV;      // union the two sets
            count++;
        }
    }
    cout << "Total cost of MST = " << totalCost << endl;
    return 0;
}

/*
=====================================================================
               FULL EXPLANATION - KRUSKAL'S ALGORITHM (MST)
=====================================================================

---------------------------------------------------------------------
PART A : THE TOPIC
---------------------------------------------------------------------
1. What is a Spanning Tree?
   For a connected, undirected graph with V vertices, a spanning tree
   is a subgraph that:
   - includes ALL V vertices,
   - is connected,
   - has NO cycle,
   - therefore has exactly V - 1 edges.

2. What is a Minimum Spanning Tree (MST)?
   Among all spanning trees of a weighted graph, the one whose total
   edge weight is the smallest. Used in network design (cables, roads,
   pipelines) to connect everything with minimum cost.

3. Kruskal's Algorithm (a GREEDY algorithm)
   - Sort all edges by weight (smallest first).
   - Go through edges one by one. Pick the edge if it does NOT form a
     cycle with already picked edges. Otherwise skip it.
   - Stop when V - 1 edges are picked.
   Why greedy works: the "cut property" - the lightest edge crossing
   any cut of the graph is always safe to include in some MST.

4. How do we check for a cycle quickly? -> Union-Find (Disjoint Set)
   - Every vertex starts in its own set.
   - FIND(x)  : returns the representative (root) of x's set.
   - UNION(x,y): joins the two sets.
   - An edge (u,v) forms a cycle if u and v are ALREADY in the same set
     (they are already connected).

5. Complexity
   - Sorting edges: O(E log E)
   - Union-Find operations: almost O(E) with optimizations
   - Total: O(E log E)  (same as O(E log V))

---------------------------------------------------------------------
PART B : EXPLANATION OF EACH PART OF THE CODE
---------------------------------------------------------------------
1. Header files: iostream for I/O, algorithm for sort().

2. struct Edge { int u, v, w; }
   Stores one edge: two end vertices u, v and the weight w.

3. int parent[100];
   The Union-Find array. parent[x] tells the parent of x in its set
   tree. If parent[x] == x, then x is the root (representative).

4. findSet(x)
   Keeps moving up: x = parent[x], until parent[x] == x. That x is the
   root of the set. Two vertices are in the same set if they have the
   same root.

5. compareEdges(a, b)
   Returns true if a.w < b.w. Passed to sort() so that edges are
   sorted in increasing order of weight.

6. main()
   a) Read V (vertices) and E (edges), then each edge u v w.
      Vertices are numbered 0 to V-1.
   b) sort(edges, edges + E, compareEdges) -> Step 1 of Kruskal.
   c) for i in 0..V-1: parent[i] = i -> every vertex is its own set.
   d) Main loop: for each edge in sorted order, while we have fewer
      than V-1 edges:
        rootU = findSet(u), rootV = findSet(v)
        if rootU != rootV:
           - u and v are in different components, so no cycle.
           - print the edge, add its weight to totalCost.
           - parent[rootU] = rootV  -> UNION of the two sets.
           - count++
        else: edge skipped (it would make a cycle).
   e) Print total cost of the MST.

   Sample: edges sorted 2,3,5,6,7,8,9. Picked (0-1,2), (1-2,3),
   (1-4,5), (0-3,6). Now 4 = V-1 edges, stop. Total = 16.

---------------------------------------------------------------------
PART C : VIVA QUESTIONS WITH ANSWERS
---------------------------------------------------------------------
Q1. How many edges does an MST have?
A.  Exactly V - 1 edges.

Q2. Is Kruskal greedy? What property makes it correct?
A.  Yes. The CUT PROPERTY: the minimum weight edge crossing any cut is
    part of some MST. Each edge Kruskal picks is the lightest edge
    joining two different components.

Q3. How do you detect a cycle in Kruskal?
A.  Using Union-Find. If both ends of an edge have the same root
    (findSet(u) == findSet(v)), adding it would make a cycle.

Q4. What is the time complexity?
A.  O(E log E), mainly due to sorting the edges.

Q5. What is the difference between Kruskal and Prim?
A.  Kruskal works edge by edge (sort all edges, join forests) and is
    good for SPARSE graphs. Prim grows ONE tree from a start vertex,
    adding the cheapest edge going out of the tree, and is good for
    DENSE graphs. Prim with a binary heap is O(E log V).

Q6. What are "union by rank" and "path compression"?
A.  Two optimizations of Union-Find.
    Union by rank: attach the shorter tree under the taller one.
    Path compression: during find, make every node point directly to
    the root. Together they make each operation almost O(1)
    (inverse Ackermann alpha(n)). This program uses the simple version
    for easy understanding.

Q7. Is the MST unique?
A.  If all edge weights are distinct, yes. If some weights are equal,
    there can be more than one MST but all have the same total cost.

Q8. What happens if the graph is not connected?
A.  We cannot get V-1 edges. Kruskal then gives a minimum spanning
    FOREST (one MST for each component).

Q9. Can Kruskal handle negative weights?
A.  Yes. MST algorithms work with negative weights since they only
    compare weights.

Q10. Why does the loop stop at count < V - 1?
A.  Because a spanning tree needs exactly V - 1 edges; after that all
    remaining edges would only create cycles.

Q11. Give real life uses of MST.
A.  Designing cheapest networks: LAN cabling, roads, electric grids,
    water pipelines; also clustering in data analysis.
=====================================================================
*/
