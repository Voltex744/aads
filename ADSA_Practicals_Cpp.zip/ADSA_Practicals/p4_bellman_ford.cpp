// Practical 4: Bellman-Ford Algorithm (single source shortest paths)
#include <iostream>
using namespace std;

const int INF = 1000000000;

struct Edge {
    int u, v, w;   // directed edge u -> v with weight w
};

int main() {
    int V, E, src;
    cout << "Enter number of vertices and edges: ";
    cin >> V >> E;

    Edge edges[100];
    cout << "Enter each edge as: u v weight (vertices numbered 0 to " << V - 1 << ")\n";
    for (int i = 0; i < E; i++)
        cin >> edges[i].u >> edges[i].v >> edges[i].w;

    cout << "Enter source vertex: ";
    cin >> src;

    // Step 1: set all distances to infinity, source to 0
    int dist[100];
    for (int i = 0; i < V; i++)
        dist[i] = INF;
    dist[src] = 0;

    // Step 2: relax all edges (V - 1) times
    for (int pass = 1; pass <= V - 1; pass++) {
        for (int j = 0; j < E; j++) {
            int u = edges[j].u, v = edges[j].v, w = edges[j].w;
            if (dist[u] != INF && dist[u] + w < dist[v])
                dist[v] = dist[u] + w;
        }
    }

    // Step 3: one more pass - if anything still improves, there is a negative cycle
    for (int j = 0; j < E; j++) {
        int u = edges[j].u, v = edges[j].v, w = edges[j].w;
        if (dist[u] != INF && dist[u] + w < dist[v]) {
            cout << "Graph contains a negative weight cycle!" << endl;
            return 0;
        }
    }

    cout << "\nVertex\tDistance from source " << src << endl;
    for (int i = 0; i < V; i++) {
        if (dist[i] == INF)
            cout << i << "\tINF (unreachable)" << endl;
        else
            cout << i << "\t" << dist[i] << endl;
    }
    return 0;
}

/*
=====================================================================
                 FULL EXPLANATION - BELLMAN-FORD ALGORITHM
=====================================================================

---------------------------------------------------------------------
PART A : THE TOPIC
---------------------------------------------------------------------
1. Single Source Shortest Path problem
   Given a weighted directed graph and a SOURCE vertex s, find the
   shortest distance from s to every other vertex.

2. Why Bellman-Ford and not Dijkstra?
   Dijkstra is faster but does NOT work correctly when some edges have
   NEGATIVE weights. Bellman-Ford works with negative weights and can
   also DETECT a negative weight cycle.

3. Relaxation (the basic step)
   For an edge u -> v with weight w:
       if dist[u] + w < dist[v]  then  dist[v] = dist[u] + w
   Meaning: "going to v through u is shorter than what we know, so
   update it".

4. Algorithm
   - dist[s] = 0, dist[others] = infinity.
   - Repeat V - 1 times: relax EVERY edge.
   - Then check all edges once more. If any edge can still be relaxed,
     the graph has a negative weight cycle (reachable from s).

5. Why exactly V - 1 times?
   A shortest path (without cycles) has at most V - 1 edges. After the
   k-th pass, all shortest paths using at most k edges are correct. So
   after V - 1 passes, all shortest paths are correct.

6. Negative weight cycle
   A cycle whose total weight is negative. Going around it again and
   again keeps reducing the distance, so the "shortest path" is not
   defined (minus infinity).

7. Complexity
   - Time  : O(V * E)
   - Space : O(V) for the dist array

---------------------------------------------------------------------
PART B : EXPLANATION OF EACH PART OF THE CODE
---------------------------------------------------------------------
1. const int INF = 1000000000;
   A very large number used as "infinity" (not yet reachable).

2. struct Edge { int u, v, w; }
   A DIRECTED edge from u to v with weight w (weight may be negative).
   We store the graph as a simple EDGE LIST, which is enough because
   Bellman-Ford just loops over all edges.

3. Input: V, E, all edges, then the source vertex src.

4. Step 1 - Initialization
   dist[i] = INF for all i, then dist[src] = 0.

5. Step 2 - Relax all edges V-1 times
   Outer loop: pass = 1 to V-1.
   Inner loop: every edge j.
      if (dist[u] != INF && dist[u] + w < dist[v]) dist[v] = dist[u] + w;
   The check dist[u] != INF is important: if u is not reached yet,
   INF + w would give a wrong value (or overflow), so we skip it.

6. Step 3 - Negative cycle check
   Loop over all edges once more. If any dist[v] can still decrease,
   print "Graph contains a negative weight cycle!" and stop.

7. Output
   Print each vertex with its distance. If dist is still INF, print
   "INF (unreachable)".

   Sample (source 0): distances 0, -1, 2, -2, 1.
   e.g. 0 -> 1 (-1) -> 4 (+2) -> 3 (-3) gives dist[3] = -2.

---------------------------------------------------------------------
PART C : VIVA QUESTIONS WITH ANSWERS
---------------------------------------------------------------------
Q1. What is relaxation?
A.  Checking if the path to v through u is shorter, and if yes,
    updating dist[v] = dist[u] + w(u,v).

Q2. Why do we relax edges V - 1 times?
A.  The longest simple shortest path has V - 1 edges. Each pass fixes
    at least one more edge of every shortest path.

Q3. How does Bellman-Ford detect a negative cycle?
A.  After V-1 passes, distances should be final. If one more pass can
    still reduce any distance, a negative weight cycle exists.

Q4. Time complexity? Compare with Dijkstra.
A.  Bellman-Ford O(VE). Dijkstra with a binary heap O((V+E) log V).
    Dijkstra is faster but fails with negative edges.

Q5. Why does Dijkstra fail with negative edges?
A.  Dijkstra marks a vertex as "final" once picked, assuming no later
    path can be shorter. A negative edge found later can make a shorter
    path, breaking this assumption.

Q6. Which design technique does Bellman-Ford use?
A.  Dynamic Programming (distance using at most k edges is built from
    distance using at most k-1 edges).

Q7. Can we stop early?
A.  Yes. If in some pass no distance changes, all distances are final
    and we can stop. (Optimization, not used here for simplicity.)

Q8. Does it work for undirected graphs?
A.  Yes, by adding each undirected edge as two directed edges. But a
    negative undirected edge itself forms a negative cycle (u-v-u).

Q9. Why the check dist[u] != INF?
A.  To avoid using unreachable vertices; INF + negative weight would
    give a false smaller value and could also overflow.

Q10. Where is Bellman-Ford used in real life?
A.  In distance-vector routing protocols like RIP, and to detect
    arbitrage (negative cycles) in currency exchange.

Q11. What is the result if a vertex is not reachable from the source?
A.  Its distance stays INF; the program prints "INF (unreachable)".
=====================================================================
*/
