// Practical 5: B-Tree (insertion, search and traversal)
// Minimum degree t = 3  ->  each node holds at most 2t-1 = 5 keys
#include <iostream>
using namespace std;

const int T = 3;   // minimum degree

struct Node {
    int keys[2 * T - 1];      // keys stored in the node
    Node* child[2 * T];       // child pointers
    int n;                    // current number of keys
    bool leaf;                // true if node has no children

    Node(bool isLeaf) {
        leaf = isLeaf;
        n = 0;
        for (int i = 0; i < 2 * T; i++)
            child[i] = NULL;
    }
};

Node* root = NULL;

// In-order traversal: prints keys in sorted order
void traverse(Node* x) {
    if (x == NULL) return;
    for (int i = 0; i < x->n; i++) {
        if (!x->leaf) traverse(x->child[i]);
        cout << x->keys[i] << " ";
    }
    if (!x->leaf) traverse(x->child[x->n]);
}

// Search for key k; returns true if found
bool search(Node* x, int k) {
    if (x == NULL) return false;
    int i = 0;
    while (i < x->n && k > x->keys[i])
        i++;
    if (i < x->n && x->keys[i] == k)
        return true;
    if (x->leaf)
        return false;
    return search(x->child[i], k);
}

// Split the full child y = x->child[i] into two nodes
void splitChild(Node* x, int i) {
    Node* y = x->child[i];
    Node* z = new Node(y->leaf);
    z->n = T - 1;

    // copy the last (T-1) keys of y into z
    for (int j = 0; j < T - 1; j++)
        z->keys[j] = y->keys[j + T];

    // copy the last T children of y into z
    if (!y->leaf)
        for (int j = 0; j < T; j++)
            z->child[j] = y->child[j + T];

    y->n = T - 1;

    // make room in x for the new child z
    for (int j = x->n; j >= i + 1; j--)
        x->child[j + 1] = x->child[j];
    x->child[i + 1] = z;

    // move the middle key of y up into x
    for (int j = x->n - 1; j >= i; j--)
        x->keys[j + 1] = x->keys[j];
    x->keys[i] = y->keys[T - 1];
    x->n++;
}

// Insert k into node x, which is guaranteed NOT full
void insertNonFull(Node* x, int k) {
    int i = x->n - 1;
    if (x->leaf) {
        // shift bigger keys right and place k
        while (i >= 0 && x->keys[i] > k) {
            x->keys[i + 1] = x->keys[i];
            i--;
        }
        x->keys[i + 1] = k;
        x->n++;
    } else {
        // find the child that should get k
        while (i >= 0 && x->keys[i] > k)
            i--;
        i++;
        if (x->child[i]->n == 2 * T - 1) {   // child is full -> split first
            splitChild(x, i);
            if (k > x->keys[i])
                i++;
        }
        insertNonFull(x->child[i], k);
    }
}

void insert(int k) {
    if (root == NULL) {
        root = new Node(true);
        root->keys[0] = k;
        root->n = 1;
        return;
    }
    if (root->n == 2 * T - 1) {          // root is full -> tree grows in height
        Node* s = new Node(false);
        s->child[0] = root;
        splitChild(s, 0);
        root = s;
    }
    insertNonFull(root, k);
}

int main() {
    int choice, key;
    do {
        cout << "\n1. Insert  2. Search  3. Display  4. Exit\nEnter choice: ";
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "Enter key to insert: ";
            cin >> key;
            insert(key);
            break;
        case 2:
            cout << "Enter key to search: ";
            cin >> key;
            if (search(root, key)) cout << key << " found in B-Tree\n";
            else cout << key << " not found\n";
            break;
        case 3:
            cout << "B-Tree (in sorted order): ";
            traverse(root);
            cout << endl;
            break;
        }
    } while (choice != 4);
    return 0;
}

/*
=====================================================================
                       FULL EXPLANATION - B-TREE
=====================================================================

---------------------------------------------------------------------
PART A : THE TOPIC
---------------------------------------------------------------------
1. What is a B-Tree?
   A B-Tree is a SELF-BALANCED search tree in which a node can have
   MANY keys and MANY children (not just 2 like a binary tree).
   It is designed for disks/databases: reading one disk block is slow,
   so we store many keys in one node (one block) and keep the tree
   very SHORT. Fewer levels = fewer disk reads.

2. Minimum degree t  (in this program T = 3)
   Every B-Tree has a number t >= 2 that decides node sizes:
   - Every node has at most 2t - 1 keys      (here 5 keys)
   - Every node has at most 2t children      (here 6 children)
   - Every node except root has at least t - 1 keys (here 2 keys)
   - Root has at least 1 key (if tree is not empty)
   - A node with n keys has n + 1 children (if not leaf)

3. Properties
   - Keys inside a node are in sorted order.
   - Keys in child[i] lie between keys[i-1] and keys[i]
     (like a binary search tree, but with many branches).
   - ALL LEAVES ARE AT THE SAME LEVEL (perfectly balanced).
   - Height is O(log_t n), very small for large t.

4. Search
   In a node, find the first key >= k. If it equals k, found.
   Otherwise go into the child at that position. Repeat.

5. Insertion (CLRS one-pass method, "split on the way down")
   - New keys are always inserted in a LEAF.
   - A full node (2t-1 keys) cannot take another key, so we SPLIT it:
     the middle key goes UP to the parent, and the node becomes two
     nodes with t-1 keys each.
   - We split every full node we meet WHILE GOING DOWN, so when we
     reach the leaf, its parent always has space for a key coming up.
   - If the ROOT is full, we split it and make a new root. This is the
     ONLY way the height of a B-Tree increases (it grows at the top,
     not at the bottom).

6. Complexity (n keys, minimum degree t)
   - Search : O(t log_t n) CPU time, O(log_t n) disk accesses
   - Insert : O(t log_t n) CPU time, O(log_t n) disk accesses
   - Height : h <= log_t ((n+1)/2)

---------------------------------------------------------------------
PART B : EXPLANATION OF EACH PART OF THE CODE
---------------------------------------------------------------------
1. const int T = 3;  -> minimum degree.

2. struct Node
   - keys[2T-1]  : array for at most 5 keys.
   - child[2T]   : array for at most 6 child pointers.
   - n           : how many keys are currently in the node.
   - leaf        : true if the node has no children.
   - Constructor Node(bool isLeaf): sets leaf, makes n = 0 and all
     child pointers NULL.

3. Node* root = NULL;  -> empty tree at start.

4. traverse(x)   (in-order traversal)
   For each key i: first visit child[i] (smaller keys), then print
   keys[i]. At the end visit the last child child[n] (largest keys).
   Result: all keys printed in SORTED order.

5. search(x, k)
   - If x is NULL -> not found.
   - Move i forward while k > keys[i].
   - If keys[i] == k -> found (return true).
   - If x is a leaf -> nowhere to go, not found.
   - Else recursively search child[i].

6. splitChild(x, i)  -- MOST IMPORTANT FUNCTION
   y = x->child[i] is FULL (5 keys). Make new node z.
   - z gets the last T-1 = 2 keys of y (keys[3], keys[4]).
   - If y is not a leaf, z also gets the last T = 3 children of y.
   - y->n = T-1 = 2  (y keeps the first 2 keys).
   - Shift x's children right and put z as child[i+1].
   - Shift x's keys right and put y's MIDDLE key (keys[T-1] = keys[2])
     into x->keys[i]. Increase x->n.
   Example: full y = [3 5 6 7 8] -> y = [3 5], z = [7 8], 6 goes up.

7. insertNonFull(x, k)   (x is guaranteed not full)
   - If x is a LEAF: shift bigger keys one place right and put k in
     the correct sorted place. n++.
   - If x is INTERNAL: find child i where k should go. If that child
     is full, split it first. After splitting, the middle key came up
     to x->keys[i]; if k is bigger than it, go to child i+1 instead.
     Then call insertNonFull on that child (recursion).

8. insert(k)
   - Empty tree: create a leaf root holding k.
   - If root is full: make new node s (not leaf), make old root its
     child[0], split it, and make s the new root. Height grows by 1.
   - Then insertNonFull(root, k).

9. main()  -> menu driven:
   1 = Insert, 2 = Search, 3 = Display (sorted order), 4 = Exit.
   Uses do-while loop and switch-case.

---------------------------------------------------------------------
PART C : VIVA QUESTIONS WITH ANSWERS
---------------------------------------------------------------------
Q1. What is a B-Tree? Why is it used?
A.  A balanced multi-way search tree where each node stores many keys.
    It is used in databases and file systems because it keeps the
    height very small, which reduces the number of disk reads.

Q2. What is the minimum degree t? What are the limits in your program?
A.  t decides the size of nodes. Here t = 3: max keys 5, max children
    6, min keys (non-root) 2.

Q3. Why are all leaves at the same level?
A.  Because the tree grows only at the ROOT (when the root splits),
    which adds one level to every path equally.

Q4. When does the height of a B-Tree increase?
A.  Only when the root is full and gets split during insertion.

Q5. What happens when a node becomes full?
A.  It is split: the middle key moves up to the parent and the node
    becomes two nodes with t-1 keys each.

Q6. Why do we split full nodes while going DOWN (pre-emptive split)?
A.  So that we never have to go back up. When a child splits, the
    parent is guaranteed to have space for the middle key. This makes
    insertion a single pass from root to leaf.

Q7. What is the time complexity of search and insert?
A.  O(log n) - more precisely O(t log_t n) CPU time and O(log_t n)
    disk accesses.

Q8. What is the difference between a B-Tree and a B+ Tree?
A.  In a B+ tree all actual data/keys are stored in leaves, internal
    nodes only guide the search, and leaves are linked together for
    fast range queries. In a B-Tree, keys are stored in internal nodes
    too.

Q9. What is a 2-3-4 tree?
A.  A B-Tree with minimum degree t = 2: every node has 2, 3 or 4
    children (1 to 3 keys). It is equivalent to a Red-Black tree.

Q10. Difference between a B-Tree and a Binary Search Tree?
A.  BST node has 1 key and 2 children and can become unbalanced
    (height up to n). B-Tree node has many keys, many children and is
    always balanced (height O(log_t n)).

Q11. Why does traverse() print keys in sorted order?
A.  It is an in-order traversal: smaller keys (left child) first, then
    the key, then larger keys, for every key in the node.

Q12. How is deletion done in a B-Tree (theory)?
A.  If the key is in a leaf, remove it. If it is in an internal node,
    replace it with its predecessor/successor. If a node would go below
    t-1 keys, BORROW a key from a sibling or MERGE with a sibling.
    (Not implemented in this program.)

Q13. What is the maximum height of a B-Tree with n keys?
A.  h <= log_t ((n + 1) / 2).
=====================================================================
*/
