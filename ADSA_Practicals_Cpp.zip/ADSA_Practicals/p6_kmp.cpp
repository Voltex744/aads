// Practical 6: Pattern searching using the KMP (Knuth-Morris-Pratt) Algorithm
#include <iostream>
#include <string>
using namespace std;

// Build the failure (LPS) array:
// fail[j] = length of the longest proper prefix of pattern[0..j]
//           that is also a suffix of pattern[0..j]
void computeFailure(string pattern, int fail[]) {
    int m = pattern.length();
    fail[0] = 0;
    int len = 0;
    int j = 1;
    while (j < m) {
        if (pattern[j] == pattern[len]) {
            len++;
            fail[j] = len;
            j++;
        } else if (len > 0) {
            len = fail[len - 1];     // fall back, don't move j
        } else {
            fail[j] = 0;
            j++;
        }
    }
}

void KMPSearch(string text, string pattern) {
    int n = text.length();
    int m = pattern.length();
    int fail[100];
    computeFailure(pattern, fail);

    cout << "Failure function: ";
    for (int k = 0; k < m; k++)
        cout << fail[k] << " ";
    cout << endl;

    int i = 0;   // index in text
    int j = 0;   // index in pattern
    bool found = false;
    while (i < n) {
        if (text[i] == pattern[j]) {
            i++;
            j++;
            if (j == m) {                         // full match
                cout << "Pattern found at index " << i - m << endl;
                found = true;
                j = fail[j - 1];                  // continue for more matches
            }
        } else if (j > 0) {
            j = fail[j - 1];                      // use failure function
        } else {
            i++;
        }
    }
    if (!found)
        cout << "Pattern not found in the text" << endl;
}

int main() {
    string text, pattern;
    cout << "Enter the text: ";
    getline(cin, text);
    cout << "Enter the pattern: ";
    getline(cin, pattern);

    KMPSearch(text, pattern);
    return 0;
}

/*
=====================================================================
                FULL EXPLANATION - KMP PATTERN MATCHING
=====================================================================

---------------------------------------------------------------------
PART A : THE TOPIC
---------------------------------------------------------------------
1. Pattern Matching problem
   Given a TEXT T of length n and a PATTERN P of length m, find all
   positions where P occurs in T.

2. Brute force (naive) method
   Try every starting position in T and compare character by character.
   On a mismatch, move the pattern ONE step right and start comparing
   again from the beginning of the pattern.
   Worst case: O(n * m). The problem: it forgets everything it already
   matched and goes BACK in the text.

3. Knuth-Morris-Pratt (KMP) idea
   When a mismatch happens after matching some characters, we already
   KNOW those characters (they equal the pattern prefix). KMP uses this
   knowledge to shift the pattern as far as possible, and it NEVER
   moves backwards in the text.

4. Failure function (also called LPS - Longest Prefix Suffix)
   fail[j] = length of the longest PROPER prefix of P[0..j] that is
             also a suffix of P[0..j].
   ("Proper" means not the whole string itself.)
   Example: P = "abacab"
     j :    0  1  2  3  4  5
     P :    a  b  a  c  a  b
     fail:  0  0  1  0  1  2
   fail[5] = 2 because "ab" is both a prefix and a suffix of "abacab".

   On a mismatch at pattern position j, we set j = fail[j-1]: we keep
   the already-matched part that is also a prefix, and continue from
   there.

5. Complexity
   - Building failure function : O(m)
   - Searching                 : O(n)
   - Total                     : O(n + m)   (LINEAR)
   - Extra space               : O(m) for the fail array

---------------------------------------------------------------------
PART B : EXPLANATION OF EACH PART OF THE CODE
---------------------------------------------------------------------
1. Header files: iostream, string.

2. computeFailure(pattern, fail)
   - fail[0] = 0 always (a single character has no proper prefix).
   - len = length of the current matching prefix-suffix (starts 0).
   - j starts from 1. Loop while j < m:
     a) pattern[j] == pattern[len]:
          the prefix-suffix grows: len++, fail[j] = len, j++.
     b) mismatch and len > 0:
          fall back: len = fail[len - 1]. Do NOT increase j; try again
          with a shorter prefix.
     c) mismatch and len == 0:
          no prefix-suffix: fail[j] = 0, j++.

3. KMPSearch(text, pattern)
   - n, m = lengths. Build fail[] and print it.
   - i = index in text, j = index in pattern.
   - Loop while i < n:
     a) text[i] == pattern[j]: move both i++ and j++.
          If j == m -> whole pattern matched. It started at index i-m.
          Print it. Set j = fail[j-1] to continue searching for more
          (overlapping) matches.
     b) mismatch and j > 0: j = fail[j-1]. i is NOT changed
          (we never go back in the text).
     c) mismatch and j == 0: nothing matched, just i++.
   - If no match found, print "Pattern not found in the text".

4. main()
   Reads text and pattern using getline() so that spaces are allowed,
   then calls KMPSearch.

   Sample: text = "abacaabaccabacabaabb", pattern = "abacab"
   fail = 0 0 1 0 1 2, pattern found at index 10 (0-based).

---------------------------------------------------------------------
PART C : VIVA QUESTIONS WITH ANSWERS
---------------------------------------------------------------------
Q1. What is the time complexity of KMP? Compare with brute force.
A.  KMP: O(n + m). Brute force: O(n * m) in the worst case.

Q2. What is the failure function / LPS array?
A.  fail[j] = length of the longest proper prefix of P[0..j] which is
    also a suffix of P[0..j]. It tells how much of the pattern we can
    reuse after a mismatch.

Q3. Why is KMP faster than brute force?
A.  It never moves the text pointer i backwards. After a mismatch, it
    uses the failure function to shift the pattern smartly, so each
    text character is processed a constant number of times.

Q4. Why is it O(n) for the search part even though there is an inner
    "fall back"?
A.  Amortized analysis: j increases at most n times in total (once per
    i++), and every fall back decreases j, so total fall backs are also
    at most n. Total steps <= 2n.

Q5. What is a "proper" prefix?
A.  A prefix that is not equal to the whole string. For "abc" the
    proper prefixes are "", "a", "ab".

Q6. Compute the failure function of "aabaaa".
A.  0 1 0 1 2 2.

Q7. Why set j = fail[j-1] after a full match?
A.  To find OVERLAPPING occurrences. E.g. pattern "aa" in text "aaaa"
    is found at 0, 1 and 2.

Q8. What is the output index - 0-based or 1-based?
A.  0-based (first character of text is index 0).

Q9. Name other pattern matching algorithms.
A.  Brute force O(nm), Boyer-Moore (fast in practice, compares from the
    right end of pattern), Rabin-Karp (uses hashing), and suffix
    tries/trees for many searches in the same text.

Q10. Does KMP need any preprocessing? Of what?
A.  Yes, preprocessing of the PATTERN (failure function) in O(m). The
    text is not preprocessed.

Q11. Why use getline() instead of cin >>?
A.  cin >> stops at a space; getline reads the whole line, so text
    and pattern may contain spaces.
=====================================================================
*/
