// Practical 7: Suffix Trie using the brute-force method (bruteForceSuffixTrie)
// Idea: insert every suffix of the text, one by one, into a standard trie.
#include <iostream>
#include <string>
using namespace std;

struct TrieNode {
    TrieNode* child[27];   // 26 letters 'a'-'z' + 1 slot for end marker '$'
    TrieNode() {
        for (int i = 0; i < 27; i++)
            child[i] = NULL;
    }
};

// Convert a character to an index: 'a'..'z' -> 0..25, '$' -> 26
int indexOf(char c) {
    if (c == '$') return 26;
    return c - 'a';
}

// Insert one string into the trie
void insert(TrieNode* root, string s) {
    TrieNode* cur = root;
    for (int i = 0; i < s.length(); i++) {
        int k = indexOf(s[i]);
        if (cur->child[k] == NULL)
            cur->child[k] = new TrieNode();
        cur = cur->child[k];
    }
}

// bruteForceSuffixTrie: insert all suffixes text[i..n-1] for i = 0 .. n-1
TrieNode* bruteForceSuffixTrie(string text) {
    TrieNode* root = new TrieNode();
    text = text + "$";                 // end marker so every suffix ends at a leaf
    for (int i = 0; i < text.length(); i++) {
        string suffix = text.substr(i);
        cout << "Inserting suffix: " << suffix << endl;
        insert(root, suffix);
    }
    return root;
}

// A pattern is in the text if it is a prefix of some suffix,
// i.e. if we can walk the pattern from the root
bool searchPattern(TrieNode* root, string p) {
    TrieNode* cur = root;
    for (int i = 0; i < p.length(); i++) {
        int k = indexOf(p[i]);
        if (k < 0 || k > 26 || cur->child[k] == NULL)
            return false;
        cur = cur->child[k];
    }
    return true;
}

// Print all suffixes stored in the trie (paths from root to leaves)
void printSuffixes(TrieNode* node, string path) {
    bool isLeaf = true;
    for (int i = 0; i < 27; i++) {
        if (node->child[i] != NULL) {
            isLeaf = false;
            char c = (i == 26) ? '$' : char('a' + i);
            printSuffixes(node->child[i], path + c);
        }
    }
    if (isLeaf)
        cout << path << endl;
}

int main() {
    string text, pattern;
    cout << "Enter the text (lowercase letters only): ";
    cin >> text;

    TrieNode* root = bruteForceSuffixTrie(text);

    cout << "\nSuffixes stored in the trie:\n";
    printSuffixes(root, "");

    char again = 'y';
    while (again == 'y') {
        cout << "\nEnter pattern to search: ";
        cin >> pattern;
        if (searchPattern(root, pattern))
            cout << "Pattern \"" << pattern << "\" is present in the text\n";
        else
            cout << "Pattern \"" << pattern << "\" is NOT present in the text\n";
        cout << "Search again? (y/n): ";
        cin >> again;
    }
    return 0;
}

/*
=====================================================================
            FULL EXPLANATION - SUFFIX TRIE (bruteForceSuffixTrie)
=====================================================================

---------------------------------------------------------------------
PART A : THE TOPIC
---------------------------------------------------------------------
1. What is a Trie?
   A trie (from "reTRIEval") is a tree used to store strings.
   - Each EDGE is labelled with one character.
   - Each path from the root spells a string (or a prefix).
   - Strings with a common prefix share the same starting path.
   Searching a word of length m takes O(m) time, no matter how many
   words are stored.

2. What is a suffix?
   A suffix of a string is a part that starts at some position and goes
   till the end. "banana" has suffixes:
   banana, anana, nana, ana, na, a  (and the empty suffix).

3. What is a Suffix Trie?
   A trie that stores ALL suffixes of a text.
   Key fact: Every substring of the text is a PREFIX of some suffix.
   So to check if a pattern P occurs in the text, just walk P from the
   root. If the walk does not fall off the trie, P is present.
   This takes only O(m) time per search (m = pattern length), which is
   very useful when we search MANY patterns in the same text.

4. The end marker '$'
   We add a special character '$' (not in the alphabet) at the end of
   the text. Without it, a suffix like "ana" would just end in the
   middle of the path of "anana" and we could not tell it is a suffix.
   With "$", every suffix ends at its OWN LEAF, so
   number of leaves = number of suffixes = n + 1.

5. bruteForceSuffixTrie method (Goodrich & Tamassia, Ref. 4)
   Simplest way to build it:
       for i = 0 to n-1:  insert suffix T[i..n-1] into the trie
   Each insert takes O(length of suffix), total
   n + (n-1) + ... + 1 = O(n^2) time.
   The trie can also have O(n^2) nodes in the worst case.

6. Suffix Trie vs Suffix Tree
   A suffix TREE is a compressed suffix trie: chains of nodes with one
   child are merged into one edge labelled by a substring. It has only
   O(n) nodes and can be built in O(n) time (Ukkonen's / McCreight's
   algorithm). The brute force trie is the simple version for
   understanding.

---------------------------------------------------------------------
PART B : EXPLANATION OF EACH PART OF THE CODE
---------------------------------------------------------------------
1. struct TrieNode
   - child[27] : 26 slots for 'a' to 'z' and 1 slot (index 26) for '$'.
   - Constructor sets all children to NULL.
   The character itself is not stored in the node; the INDEX of the
   child slot tells which character the edge represents.

2. indexOf(c)
   Converts a character to the child slot:
   'a' -> 0, 'b' -> 1, ..., 'z' -> 25, '$' -> 26.
   (c - 'a' uses ASCII values: 'c' - 'a' = 2.)

3. insert(root, s)
   Starts at root. For each character of s:
   - k = indexOf(character)
   - if child[k] is NULL, create a new node there.
   - move cur to child[k].
   This is the normal trie insertion.

4. bruteForceSuffixTrie(text)
   - Create an empty root.
   - text = text + "$"  (add end marker).
   - For each i from 0 to length-1: suffix = text.substr(i), which is
     the substring starting at i till the end. Print it and insert it.
   - Return the root.
   For "banana": inserts banana$, anana$, nana$, ana$, na$, a$, $.

5. searchPattern(root, p)
   Walk from root character by character. If at any step the required
   child is NULL (or the character is not a valid letter), the pattern
   is NOT in the text -> return false. If we finish the whole pattern,
   return true.
   "nan" -> root -n-> -a-> -n-> exists, so present.
   "nab" -> root -n-> -a-> but no 'b' child, so not present.

6. printSuffixes(node, path)
   Depth first traversal. "path" holds the characters from the root.
   For each non-NULL child, add its character to path and go deeper.
   When a node has no children (a LEAF), print path - this is one full
   suffix. Children are visited in order a..z then $, so the output is
   alphabetical with $ treated as the largest character.

7. main()
   Reads the text (lowercase letters only), builds the suffix trie,
   prints all suffixes, then repeatedly asks for a pattern to search
   until the user enters 'n'.

---------------------------------------------------------------------
PART C : VIVA QUESTIONS WITH ANSWERS
---------------------------------------------------------------------
Q1. What is a trie?
A.  A tree for storing strings where each edge represents one
    character and each root-to-node path represents a prefix.

Q2. What is a suffix trie?
A.  A trie that contains all the suffixes of a given text.

Q3. Why do we add '$' at the end of the text?
A.  So that no suffix is a prefix of another suffix. Then every suffix
    ends at a separate leaf, and leaves = number of suffixes.

Q4. How does a suffix trie help in pattern matching?
A.  Every substring of the text is a prefix of some suffix. So we just
    follow the pattern from the root; if the path exists, the pattern
    is in the text. Time O(m).

Q5. What is the time to build using bruteForceSuffixTrie?
A.  O(n^2), because we insert n suffixes of lengths n, n-1, ..., 1.

Q6. What is the space complexity?
A.  O(n^2) nodes in the worst case (e.g. all characters different).

Q7. Difference between a suffix trie and a suffix tree?
A.  A suffix tree is a compressed suffix trie: nodes with only one
    child are merged and edges hold substrings. It needs only O(n)
    space and can be built in O(n) time with Ukkonen's algorithm.

Q8. What is a compressed (Patricia) trie?
A.  A trie in which every internal node has at least 2 children;
    chains of single-child nodes are merged into one edge.

Q9. Why does each node have 27 children?
A.  26 for lowercase letters and 1 for the end marker '$'.

Q10. How many leaves does the suffix trie of "banana" have?
A.  7 (banana$, anana$, nana$, ana$, na$, a$, $) = n + 1.

Q11. Compare KMP and suffix trie for searching.
A.  KMP preprocesses the PATTERN (O(m)) and searches in O(n) each time.
    A suffix trie preprocesses the TEXT once (O(n^2) brute force) and
    then answers each pattern search in O(m). Suffix trie is better
    when we have one fixed text and MANY patterns.

Q12. Give applications of suffix tries/trees.
A.  Fast substring search, longest repeated substring, longest common
    substring of two strings, DNA sequence analysis, text editors,
    search engines.

Q13. What does substr(i) do?
A.  Returns the part of the string from index i till the end - that is
    exactly the suffix starting at position i.
=====================================================================
*/
